public class Simulation {

    private int numParticles = 50;
    public Particle[] getParticles(){
      return ;
    }
    public int getNumParticles(){
      return this.numParticles;
    }
    public void addParticles(int amount){
      this.numParticles += amount;
    }
    public void removeParticles(int amount){
      this.numParticles -= amount;
    }
    public ObstacleNode getObstacles(){
      return getObstacle();
    }
    public void addObstacle(Obstacle obstacle){
      
    }
    public removeObstacle(Obstacle obstacle){
    
    }
}
